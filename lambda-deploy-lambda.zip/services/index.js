"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var codepipeline_1 = __importDefault(require("./codepipeline"));
var lambda_1 = __importDefault(require("./lambda"));
exports.default = { codepipeline: codepipeline_1.default, lambda: lambda_1.default };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxnRUFBMEM7QUFDMUMsb0RBQThCO0FBRTlCLGtCQUFlLEVBQUUsWUFBWSx3QkFBQSxFQUFFLE1BQU0sa0JBQUEsRUFBRSxDQUFDIn0=