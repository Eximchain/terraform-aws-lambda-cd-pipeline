"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var env_1 = require("../env");
var codepipeline = new env_1.AWS.CodePipeline({ apiVersion: '2015-07-09' });
function promiseCompleteJob(jobId) {
    var maxRetries = 5;
    var params = {
        jobId: jobId
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.putJobSuccessResult(params).promise(); }, maxRetries);
}
function promiseFailJob(jobId, err) {
    var maxRetries = 5;
    var params = {
        jobId: jobId,
        failureDetails: {
            type: 'JobFailed',
            message: JSON.stringify(err)
        }
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.putJobFailureResult(params).promise(); }, maxRetries);
}
exports.default = {
    completeJob: promiseCompleteJob,
    failJob: promiseFailJob
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZXBpcGVsaW5lLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL2NvZGVwaXBlbGluZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLG9DQUFpRDtBQUNqRCw4QkFBNkI7QUFFN0IsSUFBTSxZQUFZLEdBQUcsSUFBSSxTQUFHLENBQUMsWUFBWSxDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFdEUsU0FBUyxrQkFBa0IsQ0FBQyxLQUFZO0lBQ3BDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULEtBQUssRUFBRyxLQUFLO0tBQ2hCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxZQUFZLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWxELENBQWtELEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDdEcsQ0FBQztBQUVELFNBQVMsY0FBYyxDQUFDLEtBQVksRUFBRSxHQUFPO0lBQ3pDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULEtBQUssRUFBRyxLQUFLO1FBQ2IsY0FBYyxFQUFHO1lBQ2IsSUFBSSxFQUFHLFdBQVc7WUFDbEIsT0FBTyxFQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO1NBQ2hDO0tBQ0osQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEQsQ0FBa0QsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RyxDQUFDO0FBRUQsa0JBQWU7SUFDWCxXQUFXLEVBQUUsa0JBQWtCO0lBQy9CLE9BQU8sRUFBRyxjQUFjO0NBQzNCLENBQUEifQ==