"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Provided automagically by AWS
exports.awsRegion = process.env.AWS_REGION;
// Provided by Terraform
exports.deploymentPackageBucket = process.env.DEPLOYMENT_PACKAGE_BUCKET;
exports.deploymentPackageKey = process.env.DEPLOYMENT_PACKAGE_KEY;
exports.functionsToDeploy = process.env.FUNCTIONS_TO_DEPLOY ? process.env.FUNCTIONS_TO_DEPLOY.split(',') : [];
var aws_sdk_1 = __importDefault(require("aws-sdk"));
exports.AWS = aws_sdk_1.default;
exports.AWS.config.update({ region: exports.awsRegion });
exports.default = {
    AWS: exports.AWS, awsRegion: exports.awsRegion, deploymentPackageBucket: exports.deploymentPackageBucket, deploymentPackageKey: exports.deploymentPackageKey, functionsToDeploy: exports.functionsToDeploy
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52LmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVudi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLGdDQUFnQztBQUNuQixRQUFBLFNBQVMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQW9CLENBQUM7QUFFMUQsd0JBQXdCO0FBQ1gsUUFBQSx1QkFBdUIsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUFtQyxDQUFDO0FBQzFFLFFBQUEsb0JBQW9CLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBZ0MsQ0FBQztBQUNwRSxRQUFBLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFHbkgsb0RBQXNDO0FBQ3pCLFFBQUEsR0FBRyxHQUFHLGlCQUFlLENBQUM7QUFDbkMsV0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxNQUFNLEVBQUUsaUJBQVMsRUFBQyxDQUFDLENBQUM7QUFFdkMsa0JBQWU7SUFDWCxHQUFHLGFBQUEsRUFBRSxTQUFTLG1CQUFBLEVBQUUsdUJBQXVCLGlDQUFBLEVBQUUsb0JBQW9CLDhCQUFBLEVBQUUsaUJBQWlCLDJCQUFBO0NBQ25GLENBQUMifQ==